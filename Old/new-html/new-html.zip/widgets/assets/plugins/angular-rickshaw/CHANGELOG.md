Version numbers correspond to `bower.json` version

# 0.1.0

* Initial alpha release.

## Features

## Bug Fixes

## Breaking Changes